import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-header-task',
  templateUrl: './header-task.component.html',
  styleUrls: ['./header-task.component.scss']
})
export class HeaderTaskComponent implements OnInit {
imgsrc='assets/images/listicon2.png'
  constructor() { }

  ngOnInit(): void {
  }

}
